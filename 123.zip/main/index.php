<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" type="text/css" href="/css/testcss.css">
    <link rel="stylesheet" type="text/css" href="/css/cardtest.css">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    /**/
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/6.0.0/normalize.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>

    <div class="container">
        <form action="./logincheck.php" method="post" name="join">
            <table>
                <td width="80px">아이디&nbsp;</td>
                <td width="80px"><input type="text" name="id" placeholder="아이디"></td>
                <td width="80px">패스워드</td>
                <td width="80px"><input type="text" name="pw" placeholder="패스워드"></td>
                <td width="80px"><input type="submit" value="로그인"></td>
            </table>
        </form>

        <div class="row">
            <h2>로고</h2>

            <hr/>
           <div id="wrapper"> <!--이거 막으면 메뉴 안들어감-->
                             
                <!-- Sidebar -->
               <div id="sidebar-wrapper">
                    여긴어딥니껴
                    <ul class="sidebar-nav" style="margin-left:0;">
                        1
                        <li class="sidebar-brand">
                            1
                            <a href="#menu-toggle" id="menu-toggle" style="margin-top:20px;float:right;"> <i class="fa fa-bars " style="font-size:20px !Important;" aria-hidden="true" aria-hidden="true"></i> 
                    
                </li>
                <li>
                    <a href="#"><i class="fa fa-sort-alpha-asc " aria-hidden="true"> </i> <span style="margin-left:10px;">카테고리</span>  </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-play-circle-o " aria-hidden="true"> </i> <span style="margin-left:10px;">음료</span> </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-puzzle-piece" aria-hidden="true"> </i> <span style="margin-left:10px;">과자</span> </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-font" aria-hidden="true"> </i> <span style="margin-left:10px;">드랍커피</span> </a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-info-circle " aria-hidden="true"> </i> <span style="margin-left:10px;">설정 </span> </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-comment-o" aria-hidden="true"> </i> <span style="margin-left:10px;">about</span> </a>
                        </li>
                    </ul>
                </div>
                
                여기가 맞는구나
                
                 <div class="items">
        
  <div class="items">
        <div data-price="290" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$290</h5>
                </div>
        </div>
        <div data-price="900" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item" ></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$900</h5>
                </div>
        </div>
        <div data-price="600" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$600</h5>
                </div>
        </div>
         <div data-price="457" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$457</h5>
                </div>
        </div>
         <div data-price="674" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$647</h5>
                </div>
        </div>
         <div data-price="315" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$315</h5>
                </div>
        </div>
         <div data-price="987" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$987</h5>
                </div>
        </div>
         <div data-price="777" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$777</h5>
                </div>
        </div>
         <div data-price="504" class="item">
            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSS8oEITt9vJtsCPRH0mvi2pRf8YZfN6YnkASdjsibLyayVVlidSUwG64QIWw" alt="jacket" class="img-item"></img>
                <div class="info">
                    <h3>Our Legacy Splash Jacquard Knit</h3>
                    <p class="descroption">Black Grey Plants</p>
                    <h5>$504</h5>
                </div>
        </div>
    </div>
 <button class="loadmore">Load More</button>
    </div>


                <!-- /#sidebar-wrapper -->

                <!-- Page Content -->
                <div id="page-content-wrapper">

                    <div class="container-fluid">

                        <div class="row">

                            <div class="col-lg-12">
                                </a>

                                <!-- /#page-content-wrapper -->
                                <!-- /#wrapper -->
                                <script>
                                    $("#menu-toggle").click(function(e) {
                                        e.preventDefault();
                                        $("#wrapper").toggleClass("toggled");
                                    });

                                </script>

                            </div>

                        </div>
                </div>
            </div>
        </div>

<div class="navbar navbar-inverse navbar-fixed-bottom"> 
     <div class="container">
       <div class="navbar-text pull=left">
	    <p> © company 2016.</p>
	   </div>
	      
	 </div>
   </div>

</body>

</html>
