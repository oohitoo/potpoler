<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <link rel="stylesheet" type="text/css" href="/css/testcss.css">

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
        <meta charset="UTF-8">
        <title>Document</title>
    </head>

    <body>

        <div class="container">
            <form action="./logincheck.php" method="post" name="join">
                <table>
                    <td width="80px">
                        
                        <td width="80px"><? echo $_SESSION['name'];?></td>
                <td width="80px"><? echo "<a href='logout.php'><input type='button' value='Logout'></a>";?></td>
                    </td>
                </table>
            </form>

            <div class="row">
                <h2>로고</h2>

                <hr/>
                <!-- <div id="wrapper"> 이거 막으면 메뉴 안들어감-->

                <!-- Sidebar -->
                <div id="sidebar-wrapper">
                    여긴어딥니껴
                    <ul class="sidebar-nav" style="margin-left:0;">
                        1
                        <li class="sidebar-brand">
                            1
                            <a href="#menu-toggle" id="menu-toggle" style="margin-top:20px;float:right;"> <i class="fa fa-bars " style="font-size:20px !Important;" aria-hidden="true" aria-hidden="true"></i> 
                    
                </li>
                <li>
                    <a href="#"><i class="fa fa-sort-alpha-asc " aria-hidden="true"> </i> <span style="margin-left:10px;">카테고리</span>  </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-play-circle-o " aria-hidden="true"> </i> <span style="margin-left:10px;">음료</span> </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-puzzle-piece" aria-hidden="true"> </i> <span style="margin-left:10px;">과자</span> </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-font" aria-hidden="true"> </i> <span style="margin-left:10px;">드랍커피</span> </a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-info-circle " aria-hidden="true"> </i> <span style="margin-left:10px;">설정 </span> </a>
                        </li>
                        <li>
                            <a href="#"> <i class="fa fa-comment-o" aria-hidden="true"> </i> <span style="margin-left:10px;">about</span> </a>
                        </li>
                    </ul>
                </div>

                여기가 맞는구나


                <!-- /#sidebar-wrapper -->

                <!-- Page Content -->
                <div id="page-content-wrapper">

                    <div class="container-fluid">

                        <div class="row">

                            <div class="col-lg-12">
                                </a>

                                <!-- /#page-content-wrapper -->
                                <!-- /#wrapper -->
                                <script>
                                    $("#menu-toggle").click(function(e) {
                                        e.preventDefault();
                                        $("#wrapper").toggleClass("toggled");
                                    });

                                </script>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="navbar navbar-inverse navbar-fixed-bottom">
            <div class="container">
                <div class="navbar-text pull=left">
                    <p> © company 2016.</p>
                </div>

            </div>
        </div>

    </body>

    </html>
